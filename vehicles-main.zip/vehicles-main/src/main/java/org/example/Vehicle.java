package org.example;

public interface Vehicle {
    String getType();

    String getBrand();

    double getMaxSpeed();
}
