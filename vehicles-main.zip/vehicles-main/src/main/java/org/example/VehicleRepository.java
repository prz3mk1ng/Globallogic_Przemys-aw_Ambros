package org.example;

import java.util.List;
import java.util.Map;

public interface VehicleRepository {
    Map<String, List<Vehicle>> getSampleVehicles();
}
